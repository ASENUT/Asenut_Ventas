/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author MASTER
 */
public class Conexion {
    String db="Asenut";
    String login = "ute2016";
    String pass = "ute2016";
    String url = "jdbc:mysql://107.180.58.67:3306/Asenut";

    public Conexion() {
    }
   
    
    public  Connection Conectar(){
        Connection link=null;
        try{
          Class.forName("org.gjt.mm.mysql.Driver");
            link=DriverManager.getConnection(this.url, this.login, this.pass);
        }catch(ClassNotFoundException | SQLException e){
          JOptionPane.showConfirmDialog(null, e);
      }
        return link;
    }
}
